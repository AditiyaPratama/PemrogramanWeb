<html>
<head>
    <title><?php echo $title;?></title>
</head>
<body>
   <h1><?php echo $brand;?></h1> 

   <!-- tampilkan data product disini dengan perulangan dan di dalam tabel -->
    <form>
        <table border = "1">
            <tr>
                <th>Smartphone</th> 
            </tr>
         <?php foreach ($product as $item):?>

             <tr>
                 <td><?php echo $item; ?></td>
            </tr>
        
         <?php endforeach; ?>
         </table>

</body>
</html>